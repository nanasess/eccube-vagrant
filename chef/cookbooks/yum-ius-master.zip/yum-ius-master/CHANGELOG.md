yum-ius Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the yum-ius cookbook.

v0.4.0 (2014-10-29)
-------------------
- Accounting for differences between RHEL and Centos
- Adding EL7 Support

v0.3.0 (2014-09-11)
-------------------
- Add the yum-epel::default recipe if at least one yum-ius repository managed

v0.2.0 (2014-02-14)
-------------------
- Updating test harness
- Disabling uncommonly used repositories by default


v0.1.4
------
Adding CHANGELOG.md


v0.1.0
------
initial release
